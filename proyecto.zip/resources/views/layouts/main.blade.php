<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">

    <title>Cbta 18</title>
  </head>
  <body>


 

 <nav class="navbar navbar-expand-lg navbar-light bg-light" style="background: rgb(135,224,253);
background: -moz-linear-gradient(top, rgb(135,224,253) 0%, rgb(83,203,241) 40%, rgb(5,171,224) 100%);
background: -webkit-linear-gradient(top, rgb(135,224,253) 0%,rgb(83,203,241) 40%,rgb(5,171,224) 100%);
background: linear-gradient(to bottom, rgb(135,224,253) 0%,rgb(83,203,241) 40%,rgb(5,171,224) 100%);
filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#87e0fd', endColorstr='#05abe0',GradientType=0 );">
  <a class="navbar-brand" href="http://cbta18.edu.mx/">
    <img src="casa.png">
  Cbta18</a>


  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      <li class="nav-item active">
        <a class="nav-link" href="newStudent"><img src="usuario-hombre.png">Registrate<span class="sr-only">(current)</span></a>
      </li>


    </ul>
    <form class="form-inline my-2 my-lg-0">

       <a class="nav-link" href="login"><img src="login.png">Iniciar Sesion<span class="sr-only">(current)</span></a>
    </form>
    <a href="https://www.facebook.com/Cbta-Altamirano-1492972584347354/">
    <img src="facebook-logo.png"  style="margin-left: 10px">
    </a>
  </div>
</nav>



    

    <!-- Optional JavaScript -->
    <!-- jQuery first, then Popper.js, then Bootstrap JS -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
  </body>
</html>