<?php $__env->startSection('content'); ?>
    <div class="row">


        <div class="col-md-10 center-block">
            <div class="form-group row center-block">
                <div class="center-block"><?php echo $__env->make('alerts.request', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?></div>
                <?php echo Form::open(['route' => 'reports.store', 'method' => 'POST']); ?>

                <input type="hidden" value="<?php echo e(csrf_token()); ?>">
                <div class="form-group row">
                <?php echo Form::label('rol_id','Alumno:',['class' => 'col-md-1 col-form-label']); ?>

                <div class="col-md-8">
                    <select name="id_student" id="" class="form-control">
                        <option value="0" disabled selected>Selecciona una opcion</option>
                        <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($student->roles->name == "Alumno"): ?>
                            <option value="<?php echo e($student->id); ?>"><?php echo e($student->name); ?></option>
                            <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>
            <div class="form-group row">
                <?php echo Form::label('rol_id','Profesor:',['class' => 'col-md-1 col-form-label']); ?>

                <div class="col-md-8">
                    <?php echo Form::text('name_teacher',null,['class'=>'form-control','required'=>'required','placeholder' => 'Ing. Frumencio Carranza Lorenzo']); ?>

                </div>
            </div>
            <div class="form-group row">
                <?php echo Form::label('rol_id','Razón:',['class' => 'col-md-1 col-form-label']); ?>

                <div class="col-md-8">
                    <?php echo Form::text('reason',null,['class'=>'form-control','required'=>'required','placeholder' => 'Honores a la Bandera']); ?>

                </div>
            </div>
            <div class="form-group row">
                <?php echo Form::label('rol_id','Descripcion:',['class' => 'col-md-1 col-form-label']); ?>

                <div class="col-md-8">
                    <?php echo Form::text('description',null,['class'=>'form-control','required'=>'required','placeholder' => 'El alumno estaba haciendo desorden en honores a la bandera ']); ?>

                </div>
            </div>
            <div class="form-group row">
                <?php echo Form::label('rol_id','Horas:',['class' => 'col-md-1 col-form-label']); ?>

                <div class="col-md-8">
                    <?php echo Form::text('signed_hour',null,['class'=>'form-control','required'=>'required','placeholder' => '5']); ?>

                </div>
            </div>
            <div class="form-group row">
                <?php echo Form::label('','',['class' => 'col-md-1 col-form-label']); ?>

                <div class="col-md-8">
                    <?php echo Form::submit('Guardar',['class' => 'btn btn-primary']); ?>

                    <a href="<?php echo e(URL('/reports')); ?>" class="btn btn-danger">Cancelar</a>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>