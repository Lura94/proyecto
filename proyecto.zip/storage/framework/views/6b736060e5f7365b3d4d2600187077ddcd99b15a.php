<?php $__env->startSection('content'); ?>
    <div class="form-body center-block">
        <div class="row">
            <div class="col-md-10 center-block">
                <div class="form-group">

                    <?php echo Form::open(['route' => 'students.find', 'method' => 'POST']); ?>

                    <?php echo Form::label('rol_id','Numero de control:',['class' => 'col-md-2 col-form-label', 'required']); ?>

                    <div class="col-md-10">
                        <div class="col-md-3">
                            <?php echo Form::text('ncontrol',null,['class'=>'form-control','placeholder' => '1307003030']); ?>

                        </div>
                        <div class="col-md-2">
                            <?php echo Form::submit('Aceptar',['class' => 'btn btn-primary']); ?>

                            <?php echo Form::close(); ?>

                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php echo Form::label('rol_id','Total de Horas:',['class' => 'col-md-6 col-form-label']); ?>

                                <div class="col-md-5">
                                    <?php if(isset($cantRep) && $cantRep !=0): ?>
                                            <label for="" class="form-control"><?php echo e($cantRep); ?></label>
                                       <?php endif; ?>
                                </div>

                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <?php if(isset($idStudent) && $reports !=null): ?>
                                <a href="<?php echo e(URL::to("reports/export/".$idStudent->id)); ?>" class="btn btn-primary" style="float: right">Exportar</a>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="form-group" style="margin-top: 50px">
                    <table class="table table-bordered">
                        <thead>
                        <th class="text-center">Razón</th>
                        <th class="text-center">Descripción</th>
                        <th class="text-center">Horas</th>
                        <th class="text-center">Fecha de reporte</th>
                        </thead>
                        <tbody>
                        <?php if(isset($reports)): ?>
                            <?php $__currentLoopData = $reports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($report->reason); ?></td>
                                    <td class="text-center"><?php echo e($report->description); ?></td>
                                    <td class="text-center"><?php echo e($report->signed_hour); ?></td>
                                    <td class="text-center"><?php echo e($report->created_at); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <script type="application/javascript">
        $(document).ready(function(){
            $(".home, .students, .users, .studentsonly, .reports").css("background-color","transparent")
            $(".studentsonly").css("background-color", "rgb(135,224,253)");
        });
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>