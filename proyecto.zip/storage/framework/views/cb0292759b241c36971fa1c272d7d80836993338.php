<?php $__env->startSection('content'); ?>
    <div class="form-body center-block">
        <div class="row">
            <div class="col-md-10 center-block">
                <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="form-group">
                    <a href="<?php echo e(URL('/users/create')); ?>" class="btn btn-primary pull-right" style="margin-bottom: 10px">
                        <li class="glyphicon glyphicon-plus"></li>
                        Nuevo usuario</a>
                    <?php echo e(Form::open(["route" => "users.filter", "method" => "POST"])); ?>

                    <input type="text" name="filter" class="control-label" id="filter" placeholder="Filtrar Por Nombre">
                    <button type="submit"  class="btn btn-primary" style="margin-left: 10px">Aplicar Filtro</button>
                    <?php echo e(Form::close()); ?>

                </div>
                <table class="table table-bordered" id="sample_editable_1">
                    <thead>
                    <th class="text-center">Nombre</th>
                    <th class="text-center">Telefono</th>
                    <th class="text-center">Rol</th>
                    <th class="text-center">email</th>
                    <th class="text-center">Operaciones</th>
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($user->roles->name == "Administrador"): ?>
                            <tr>
                                <td class="text-center"><?php echo e($user->name); ?></td>
                                <td class="text-center"><?php echo e($user->phone); ?></td>
                                <td class="text-center"><?php echo e($user->roles->name); ?></td>
                                <td class="text-center"><?php echo e($user->email); ?></td>
                                <td class="text-center">
                                    <?php if(Auth::user()->id != $user->id && Auth::user()->rolet != 1): ?>
                                        <a href="<?php echo e(route('users.edit', $user->id)); ?>" title="Editar usuario"
                                           class="btn glyphicon glyphicon-edit fa-2x ">
                                        </a>

                                        <a href="#exampleModal" data-toggle="modal" data-name="<?php echo e($user->name); ?>"
                                           data-id="<?php echo e($user->id); ?>" title="Eliminar"
                                           class="btn glyphicon glyphicon-trash fa-2x text-danger pull-right modalDelete">
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($users->render()); ?>

            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Eliminar Usuario</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="bodyDelete">

                </div>
                <div class="modal-footer">
                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">
                    <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="deleteUser()">Aceptar</button>
                    <button type="button" class="btn btn-danger " data-dismiss="modal"></i>Cancelar</button>
                </div>
            </div>
        </div>
    </div>
    <script type="application/javascript">
        $(document).ready(function(){
            $(".home, .students, .studentsonly, .reports").css("background-color","transparent")
            $(".users").css("background-color", "rgb(135,224,253)");
        });

        $(".modalDelete").click(function(){
            id = $(this).data("id");
            var name = $(this).data("name");
            var nodeName=document.createElement("p");
            var nameNode=document.createTextNode("¿Seguro que desea eliminar el usuario "+name+"?");
            nodeName.appendChild(nameNode);
            $("#bodyDelete").empty();
            document.getElementById("bodyDelete").appendChild(nodeName);
        });
        function deleteUser() {
                var token = $("#token").val();
                var user_id = id;

                $.ajax({
                    url: "users/"+id+"",
                    headers: {'X-CSRF-TOKEN': token},
                    type: "DELETE",
                    success: function() {
                        window.location = "/users";
                        $("#message").fadeIn();
                    }
                });
        }


    </script>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>