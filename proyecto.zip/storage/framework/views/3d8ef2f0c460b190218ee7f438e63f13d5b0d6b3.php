<?php $__env->startSection('content'); ?>
    <div class="form-body center-block">
        <div class="row">
            <div class="col-md-10 center-block">
                <?php echo $__env->make('alerts.success', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <div class="form-group">
                    <a href="<?php echo e(URL('students/export')); ?>" class="btn btn-primary pull-right" style="margin-left: 10px">Exportar</a>
                    <a href="<?php echo e(URL('/students/create')); ?>" class="btn btn-primary pull-right"
                       style="margin-bottom: 10px">
                        <li class="glyphicon glyphicon-plus"></li>
                        Nuevo Estudiante</a>
                     <?php echo e(Form::open(["route" => "students.filter", "method" => "POST"])); ?>

                    <input type="text" name="filter" class="control-label" id="filter" placeholder="Filtrar Por Nombre">
                    <button type="submit"  class="btn btn-primary" style="margin-left: 10px">Aplicar Filtro</button>
                    <?php echo e(Form::close()); ?>


                </div>
                <table class="table table-bordered">
                    <thead style="font-size: 13">
                    <th class="text-center">Nombre</th>
                    <th class="text-center">N° Control</th>
                    <th class="text-center">Curp</th>
                    <th class="text-center">Grado</th>
                    <th class="text-center">Especialidad</th>
                    <th class="text-center">Grupo</th>
                    <th class="text-center">Correo Electronico</th>
                    <th class="text-center">Tel. Alumno</th>
                    <th class="text-center">IMSS</th>
                    <th class="text-center">Tutor</th>
                    <th class="text-center">Telefono Tutor</th>

                    <th class="text-center">Operaciones</th>
                    
                    </thead>
                    <tbody>
                    <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($student->roles->name  != "Administrador"): ?>
                            <tr style="font-size: 12px ">
                                <td class="text-center"><?php echo e($student->name); ?></td>
                                <td class="text-center"><?php echo e($student->ncontrol); ?></td>
                                <td class="text-center"><?php echo e($student->curp); ?></td>
                                <td class="text-center"><?php echo e($student->grade); ?></td>
                                <td class="text-center"><?php echo e($student->specialty); ?></td>
                                <td class="text-center"><?php echo e($student->grup); ?></td>
                                <td class="text-center"><?php echo e($student->email); ?></td>
                                <td class="text-center"><?php echo e($student->phone); ?></td>
                                <td class="text-center"><?php echo e($student->imss); ?></td>
                                <td class="text-center"><?php echo e($student->tutor); ?></td>
                                <td class="text-center"><?php echo e($student->phoneTutor); ?></td>
                                <td class="text-center">
                                    <a href="<?php echo e(route('students.edit', $student->id)); ?>" title="Editar Alumno"
                                       class="btn glyphicon glyphicon-edit fa-2x ">
                                    </a>
                                    <?php if(Auth::user()->id != $student->id): ?>
                                        <a href="#exampleModal" data-toggle="modal" data-name="<?php echo e($student->name); ?>"
                                           data-id="<?php echo e($student->id); ?>" title="Eliminar"
                                           class="btn glyphicon glyphicon-trash fa-2x text-danger pull-right modalDelete">
                                        </a>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
                <?php echo e($students->render()); ?>

            </div>
        </div>
    </div>
    <!-- Modal -->
    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
         aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Eliminar Alumno</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body" id="bodyDelete">

                </div>
                <div class="modal-footer">
                    <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token" id="token">
                    <button type="button" class="btn btn-primary" data-dismiss="modal" onclick="deleteStudent()">Aceptar</button>
                    <button type="button" class="btn btn-danger " data-dismiss="modal"></i>Cancelar</button>
                </div>
            </div>
        </div>
    </div>
    <script type="application/javascript">
        $(document).ready(function(){
            $(".home, .users, .studentsonly, .reports").css("background-color","transparent")
            $(".students").css("background-color", "rgb(135,224,253)");
        });

        $(".modalDelete").click(function(){
            id = $(this).data("id");
            var name = $(this).data("name");
            var nodeName=document.createElement("p");
            var nameNode=document.createTextNode("¿Seguro que desea eliminar el Alumno "+name+"?");
            nodeName.appendChild(nameNode);
            $("#bodyDelete").empty();
            document.getElementById("bodyDelete").appendChild(nodeName);
        });
        function deleteStudent() {
            var token = $("#token").val();
            var user_id = id;

            $.ajax({
                url: "students/"+id+"",
                headers: {'X-CSRF-TOKEN': token},
                type: "DELETE",
                success: function() {
                    window.location = "/students";
                    $("#message").fadeIn();
                }
            });
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>